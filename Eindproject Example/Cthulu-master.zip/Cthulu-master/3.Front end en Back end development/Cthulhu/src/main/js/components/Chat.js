//Pagina voor de chat tussen promo en admin
import React from 'react';

import Nav from './Nav'
import Notification from './Notification'

class Chat extends React.Component {
    render() {
      return <div className="DarkLayer">
                <div className="FlexMiddle">
                    <div className="Notification">
                        <h1>Notifications</h1>
                    </div>
                    </div>
                </div>;
    }
  }

export default Chat