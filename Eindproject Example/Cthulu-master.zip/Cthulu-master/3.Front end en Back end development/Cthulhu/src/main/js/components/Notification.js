//Notificatie
import React from 'react'


class Notification extends React.Component{
    render(){
        return <div className="comment">
            <p>UserName</p>
            <p>Comment.value</p>
        </div>
    }
}

export default Notification